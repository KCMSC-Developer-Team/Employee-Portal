import { EDUCATION_LEVELS, EDUCATION_LEVEL_LABEL } from "@/lib/labels";

/**
 * The ONLY columns a staff import can read. Anything not mapped to one of these is ignored — it is never
 * extracted from the workbook. In particular there is no password column and nothing confidential.
 */
export interface ImportTarget { key: string; label: string; required?: boolean; aliases: string[] }

const EDU_FIELDS: Array<[string, string, string[]]> = [
  ["institution", "Institution", ["institution", "school", "college", "institute"]],
  ["boardOrUniversity", "Board/University", ["board", "university", "board university"]],
  ["subject", "Subject/Group", ["subject", "group", "major"]],
  ["passingYear", "Passing year", ["year", "passing year", "pass year"]],
  ["result", "Result", ["result", "gpa", "cgpa", "grade", "percentage"]],
];

export const TARGETS: ImportTarget[] = [
  { key: "staffId", label: "Staff ID", required: true, aliases: ["staff id", "id no", "id", "employee id", "staff no"] },
  { key: "name", label: "Name", required: true, aliases: ["name", "full name", "employee name", "name of employee"] },
  { key: "designation", label: "Designation", aliases: ["designation", "post", "position"] },
  { key: "category", label: "Joined as", aliases: ["joined as", "category", "employment type", "type"] },
  { key: "department", label: "Department", aliases: ["department", "dept", "section"] },
  { key: "joiningDate", label: "Joining date", aliases: ["joining date", "date of joining", "joined on", "doj"] },
  { key: "dateOfBirth", label: "Date of birth", aliases: ["date of birth", "dob", "birth date", "birthday"] },
  { key: "subject", label: "Subject", aliases: ["subject", "discipline", "academic discipline"] },
  { key: "additionalQualifications", label: "Additional qualifications", aliases: ["additional qualifications", "other qualifications"] },
  { key: "mobile", label: "Mobile", aliases: ["mobile", "mobile no", "phone", "contact", "cell"] },
  { key: "email", label: "Email", aliases: ["email", "e-mail", "email address"] },
  { key: "maritalStatus", label: "Marital status", aliases: ["marital status", "marital"] },
  { key: "bloodGroup", label: "Blood group", aliases: ["blood group", "blood"] },
  { key: "homeDistrict", label: "Home district", aliases: ["home district", "district"] },
  { key: "nidOrPassport", label: "NID/Passport", aliases: ["nid", "nid passport", "nid no", "passport", "nid/passport"] },
  { key: "presentAddress", label: "Present address", aliases: ["present address"] },
  { key: "permanentAddress", label: "Permanent address", aliases: ["permanent address"] },
  ...EDUCATION_LEVELS.flatMap((lvl) =>
    EDU_FIELDS.map(([f, label, al]) => ({
      key: `edu.${lvl}.${f}`, label: `${EDUCATION_LEVEL_LABEL[lvl]} – ${label}`,
      aliases: al.map((a) => `${EDUCATION_LEVEL_LABEL[lvl].toLowerCase()} ${a}`),
    })),
  ),
  { key: "edu.OTHER.title", label: "Other degree/training – Name", aliases: ["other degree training", "other degree", "training", "other degree training name"] },
  ...["1", "2", "3"].flatMap((n) =>
    [["organization", "Organization", ["organization", "employer", "institution"]], ["designation", "Designation", ["designation", "post"]],
     ["startDate", "From", ["from", "start", "start date"]], ["endDate", "To", ["to", "end", "end date"]]].map(([f, label, al]) => ({
      key: `exp.${n}.${f}`, label: `Experience ${n} – ${label}`, aliases: (al as string[]).map((a) => `experience ${n} ${a}`),
    })),
  ),
];

export const TARGET_KEYS = new Set(TARGETS.map((t) => t.key));
export const REQUIRED_KEYS = TARGETS.filter((t) => t.required).map((t) => t.key);

export const normHeader = (h: string) => h.toLowerCase().replace(/[^a-z0-9/ ]+/g, " ").replace(/\s+/g, " ").trim();

/** Auto-suggestion by exact normalised alias match; each target used at most once. Users confirm/adjust it. */
export function suggestMapping(headers: string[]): Record<string, string> {
  const used = new Set<string>();
  const out: Record<string, string> = {};
  for (const h of headers) {
    const n = normHeader(h);
    const t = TARGETS.find((x) => !used.has(x.key) && (normHeader(x.label) === n || x.aliases.includes(n)));
    if (t) { out[h] = t.key; used.add(t.key); } else out[h] = "";
  }
  return out;
}

export function validateMapping(map: Record<string, string>): string | null {
  const targets = Object.values(map).filter(Boolean);
  if (targets.some((t) => !TARGET_KEYS.has(t))) return "Unknown target column.";
  if (new Set(targets).size !== targets.length) return "Each field can be mapped from only one column.";
  for (const k of REQUIRED_KEYS) if (!targets.includes(k)) return `Map a column to "${TARGETS.find((t) => t.key === k)!.label}".`;
  return null;
}
